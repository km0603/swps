from setuptools import setup

setup(name='biblioteka',
    version='1.0',
    description='to jest biblioteka',
    author='Krzysztof',
    license='for internal use')
    